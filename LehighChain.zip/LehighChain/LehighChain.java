import java.util.ArrayList;
import com.google.gson.GsonBuilder;

public class LehighChain {

	public static ArrayList<Block> blockchain = new ArrayList<Block>();
	public static int difficulty = 5;

	public static void main(String[] args) {
		//add our blocks to the blockchain ArrayList:

		System.out.println("6:23:13 UTC-4 | ENERGY DISPATCH (SOLAR)  | Talen Energy Corporation");
		System.out.println("              | -1000 MWh                | 835 Hamilton Street, Allentown, PA 18101");
		addBlock(new Block("Block 1", "0"));

		System.out.println("\n6:23:52 UTC-4 | ENERGY COLLECT (SOLAR)   | Borough of Kutztown Electric Department");
		System.out.println("              | +500 MWh                 | 45 Railroad Street, Kutztown, PA 19530");
		addBlock(new Block("Block 2",blockchain.get(blockchain.size()-1).hash));

		System.out.println("\n6:24:14 UTC-4 | ENERGY COLLECT (SOLAR)   | UGI Corporation");
		System.out.println("              | +300 MWh                 | 1049 Hellertown Road, Bethlehem, PA 18015");
		addBlock(new Block("Block 3",blockchain.get(blockchain.size()-1).hash));

		System.out.println("\n6:24:48 UTC-4 | ENERGY COLLECT (SOLAR)   | PPL Electric Utilities Corporation");
		System.out.println("              | +200 MWh                 | 1 Orchard Lane, Bethlehem, PA 18017");
		addBlock(new Block("Block 4",blockchain.get(blockchain.size()-1).hash));

		System.out.println("\nBlockchain is Valid: " + isChainValid());

		String blockchainJson = StringUtil.getJson(blockchain);
		System.out.println("\nThe block chain: ");
		System.out.println(blockchainJson);
	}

	public static Boolean isChainValid() {
		Block currentBlock;
		Block previousBlock;
		String hashTarget = new String(new char[difficulty]).replace('\0', '0');

		//loop through blockchain to check hashes:
		for(int i=1; i < blockchain.size(); i++) {
			currentBlock = blockchain.get(i);
			previousBlock = blockchain.get(i-1);
			//compare registered hash and calculated hash:
			if(!currentBlock.hash.equals(currentBlock.calculateHash()) ){
				System.out.println("Current Hashes not equal");
				return false;
			}
			//compare previous hash and registered previous hash
			if(!previousBlock.hash.equals(currentBlock.previousHash) ) {
				System.out.println("Previous Hashes not equal");
				return false;
			}
			//check if hash is solved
			if(!currentBlock.hash.substring( 0, difficulty).equals(hashTarget)) {
				System.out.println("This block hasn't been mined");
				return false;
			}

		}
		return true;
	}

	public static void addBlock(Block newBlock) {
		newBlock.mineBlock(difficulty);
		blockchain.add(newBlock);
	}
}
